import React from "react"
import {
 BarChart3,
 CalendarRange,
 Coins,
 Compass,
 Globe2,
 Layers3,
 Radar,
 RefreshCw,
 Search,
 Users2,
 Video,
 type LucideIcon,
} from "lucide-react"
import {
 ANALYTICS_SYNC_REGISTRY,
 type AnalyticsSyncAction,
} from "../../services/analytics/SyncPipeline"
import { CSV_MAJOR_FAMILY_STYLES } from "../../services/csvTaxonomy"
import type { ConnectionUiState } from "../../services/connectionState"
import { readYouTubeAnalyticsCache } from "../../services/analytics/DataStore"

type SyncOptions = {
 batchMode?: "initial" | "next"
 enrichmentMode?: "core" | "video_metrics" | "traffic" | "segments" | "all"
 syncAction?: AnalyticsSyncAction
 syncButtonId?: string
}

type ChannelDataSyncControlsProps = {
 isSyncing: boolean
 lastSyncComplete: string | null
 activeSyncAction: AnalyticsSyncAction | null
 activeSyncButtonId: string | null
 connectionState: ConnectionUiState
 globalSyncData: (options?: SyncOptions) => Promise<void>
}

type ActionButtonConfig = {
 id: string
 action: AnalyticsSyncAction
 label: string
 description: string
 railClass: string
 icon: LucideIcon
 iconClassName?: string
}

const ACTIONS_BY_KEY = new Map(
 ANALYTICS_SYNC_REGISTRY.map((row) => [row.action, row] as const),
)

const ACTION_BUTTONS: ActionButtonConfig[] = [
 {
  id: "core-sync",
  action: "core_video_data",
  label: "Sync Core Video Data",
  description: "Save the baseline channel profile, uploaded video list, titles, thumbnails, dates, durations, and public row stats.",
  railClass: "bg-[#4FFF5B]",
  icon: RefreshCw,
 },
 {
  id: "load-next-250",
  action: "core_video_data",
  label: "Load Next 250 Videos",
  description: "Fetch the next 250 uploaded videos and extend the saved channel inventory deeper into the catalog.",
  railClass: "bg-[#CCFF00]",
  icon: Video,
 },
 {
  id: "google-search",
  action: "google_search",
  label: "Sync Google Search",
  description: "Fetch owned-page Google queries from Search Console, plus lane-separated YouTube search and Google-origin external referral intelligence.",
  railClass: "bg-[#C9F830]",
  icon: Search,
 },
 {
  id: "video-metrics",
  action: "video_metrics",
  label: "Sync More Video Metrics",
  description: "Add deeper per-video analytics like engaged views, saves, revenue, and format-specific metrics on top of the baseline rows.",
  railClass: "bg-[#24D3FF]",
  icon: BarChart3,
 },
 {
  id: "daily-metrics",
  action: "daily_metrics",
  label: "Sync Daily Metrics",
  description: "Add day-by-day channel rows with the real current analytics date span and the verified daily metric set.",
  railClass: "bg-[#FFFF61]",
  icon: CalendarRange,
 },
 {
  id: "traffic",
  action: "traffic",
  label: "Sync Traffic",
  description: "Fetch traffic-source overview plus supported day, video, and detail breakdowns for discovery and attribution analysis.",
  railClass: "bg-[#4FFF5B]",
  icon: Compass,
 },
 {
  id: "geography",
  action: "geography",
  label: "Sync Geography",
  description: "Fetch country-level geography plus any supported province and city splits for where viewers are coming from.",
  railClass: "bg-[#579AFF]",
  icon: Globe2,
  iconClassName: "text-white",
 },
 {
  id: "audience",
  action: "audience",
  label: "Sync Audience",
  description: "Fetch age, gender, and subscribed-status audience composition for deeper audience profiling.",
  railClass: "bg-[#FFB570]",
  icon: Users2,
 },
 {
  id: "surfaces-discovery",
  action: "surfaces_discovery",
  label: "Sync Surfaces & Discovery",
  description: "Fetch playback location and supported discovery surface breakdowns when those reports are available.",
  railClass: "bg-[#40C6E9]",
  icon: Radar,
 },
 {
  id: "revenue-monetization",
  action: "revenue_monetization",
  label: "Sync Revenue & Monetization",
  description: "Fetch revenue, monetized playback, ad impression, CPM, and ad-type analytics for monetization analysis.",
  railClass: "bg-[#B14AED]",
  icon: Coins,
  iconClassName: "text-white",
 },
 {
  id: "deep-data",
  action: "deep_data",
  label: "Sync All Deep Data",
  description: "Run the broad deep-data pass across traffic, audience, geography, monetization, and extended analytics families.",
  railClass: "bg-[#FF7AF5]",
  icon: Layers3,
 },
]

const actionFootnote = (action: AnalyticsSyncAction): string | null => {
 if (action === "daily_metrics") {
  const cache = readYouTubeAnalyticsCache() as {
   profile?: { publishedAt?: string }
   channelBaseline?: { publishedAt?: string }
  }
  const endDate = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
  const baselineDate =
   cache.channelBaseline?.publishedAt ||
   cache.profile?.publishedAt ||
   "2005-02-14T00:00:00.000Z"
  const startDate = new Date(baselineDate)
  const safeStart = Number.isNaN(startDate.getTime())
   ? new Date("2005-02-14T00:00:00.000Z")
   : startDate
  const dayCount =
   Math.max(1, Math.round((endDate.getTime() - safeStart.getTime()) / 86_400_000) + 1)
  const dateLabel = endDate.toLocaleDateString("en-US", {
   month: "short",
   day: "numeric",
   year: "numeric",
  })
  return `${dayCount.toLocaleString()} daily rows through ${dateLabel}: views, watch time, avg view duration, subs gained/lost, revenue, likes, dislikes, comments, shares, engaged views, saves.`
 }
 const row = ACTIONS_BY_KEY.get(action)
 if (!row?.runtimeBehavior) return null
 if (row.runtimeBehavior === "shared_enrichment_path") {
  return row.action === "daily_metrics"
   ? null
   : "Runs through the broader enrichment pipeline for this analytics family."
 }
 return null
}

const connectionCopy: Record<
 ConnectionUiState,
 { chip: string; helper: string }
> = {
 disconnected: {
  chip: "Connect channel first",
  helper: "Connect once, then run only the exact sync families you need.",
 },
 connected: {
  chip: "Connected sync paths ready",
  helper: "Start with core sync, then expand only the families you actually need.",
 },
 syncing: {
  chip: "Sync running now",
  helper: "Only the selected action tile should animate while the current sync is active.",
 },
}

export const ChannelDataSyncControls: React.FC<ChannelDataSyncControlsProps> = ({
 isSyncing,
 lastSyncComplete,
 activeSyncAction,
 activeSyncButtonId,
 connectionState,
 globalSyncData,
}) => {
 const runAction = (config: ActionButtonConfig) => {
  if (config.id === "load-next-250") {
   return globalSyncData({
    batchMode: "next",
    syncAction: config.action,
    syncButtonId: config.id,
   })
  }
  const row = ACTIONS_BY_KEY.get(config.action)
  return globalSyncData({
   batchMode: row?.batchMode,
   enrichmentMode: row?.enrichmentMode,
   syncAction: config.action,
   syncButtonId: config.id,
  })
 }

 const syncChip =
  connectionCopy[connectionState].chip ||
  (lastSyncComplete ? "Connected sync paths ready" : "Start with core sync")

 return (
  <div className="border-[4px] border-black rounded-[28px] bg-white p-4 md:p-5 shadow-[6px_6px_0px_0px_black]">
   <div className="flex flex-col gap-2 border-b-[3px] border-black pb-4">
    <div className="flex items-center justify-between gap-3">
     <div>
      <p className="text-[11px] font-[1000] uppercase tracking-[0.24em] text-black/45">
       Channel Data Actions
      </p>
      <p className="mt-2 text-[24px] font-[1000] uppercase leading-none">
       Sync, expand, and enrich channel statistics
      </p>
     </div>
     <div className="hidden xl:flex items-center rounded-full border-[3px] border-black bg-[#F4F1EB] px-3 py-2 text-[10px] font-black uppercase tracking-[0.18em] text-black/55">
      {syncChip}
     </div>
    </div>
    <p className="text-[12px] font-bold leading-5 text-black/65 max-w-[980px]">
     {connectionCopy[connectionState].helper}
    </p>
   </div>

   <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3">
    {ACTION_BUTTONS.map((action) => {
     const Icon = action.icon
     const showSpinner =
      isSyncing &&
      (activeSyncButtonId === action.id ||
       (!activeSyncButtonId && activeSyncAction === action.action))
     const footnote = actionFootnote(action.action)
     const toneClass =
      CSV_MAJOR_FAMILY_STYLES[
       ACTIONS_BY_KEY.get(action.action)?.datasetFamily as keyof typeof CSV_MAJOR_FAMILY_STYLES
      ]?.pillClass || "bg-white"
     return (
      <button
       key={action.id}
       onClick={() => runAction(action)}
       disabled={isSyncing}
       title={action.description}
       className={`group min-h-[126px] border-[3px] border-black rounded-[20px] bg-white text-left overflow-hidden transition-all shadow-[4px_4px_0px_0px_black] ${
        isSyncing
         ? showSpinner
           ? "ring-2 ring-black -translate-y-0.5"
           : "opacity-55 cursor-not-allowed"
         : "hover:-translate-y-0.5 active:translate-x-[2px] active:translate-y-[2px] active:shadow-[2px_2px_0px_0px_black]"
       }`}
      >
       <div className="flex h-full">
        <div
         className={`w-[60px] shrink-0 border-r-[3px] border-black ${action.railClass} flex items-center justify-center`}
        >
         {showSpinner ? (
          <RefreshCw size={20} strokeWidth={3.25} className="animate-spin text-black" />
         ) : (
          <Icon
           size={20}
           strokeWidth={3}
           className={action.iconClassName || "text-black"}
          />
         )}
        </div>
        <div className="flex-1 px-3 py-3 flex flex-col gap-1.5 justify-center">
         <span className="text-[12px] font-[1000] uppercase tracking-tight leading-[1.05] text-black">
          {action.label}
         </span>
         <span className="text-[10px] font-bold normal-case leading-4 text-black/70">
          {action.description}
         </span>
         {footnote ? (
          <span className="text-[9px] font-black normal-case leading-4 text-black/55">
           {footnote}
          </span>
         ) : (
          <span
           className={`inline-flex w-fit items-center rounded-full border-[2px] border-black px-2 py-0.5 text-[8px] font-black uppercase tracking-[0.16em] ${toneClass}`}
          >
           Ready
          </span>
         )}
        </div>
       </div>
      </button>
     )
    })}
   </div>
  </div>
 )
}

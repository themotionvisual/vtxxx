import React, { createContext, useContext, useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import { Sidebar } from "../components/Sidebar";
import { TopBar } from "../components/TopBar";
import { DashboardProvider } from "../context/DashboardContext";
import {
  ENTITLEMENT_CHANGED_EVENT,
  entitlementStatesEqual,
  readCurrentEntitlement,
  syncEntitlementIfDrifted,
  type EntitlementState,
} from "../services/billingEntitlement";

interface AppShellProps {
  children: React.ReactNode;
}

type MobileDrawerState = "closed" | "opening" | "open" | "closing";

const EntitlementContext = createContext<EntitlementState | null>(null);

const MOBILE_DRAWER_ANIMATION_MS = 280;

export const useEntitlement = (): EntitlementState => {
  const context = useContext(EntitlementContext);
  if (!context) return readCurrentEntitlement();
  return context;
};

export const AppShell: React.FC<AppShellProps> = ({ children }) => {
  const location = useLocation();
  const [entitlement, setEntitlement] = useState<EntitlementState>(() => readCurrentEntitlement());
  const [isMobile, setIsMobile] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    return window.innerWidth < 768;
  });
  const [sidebarHidden, setSidebarHidden] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    if (window.innerWidth < 768) return true;
    return localStorage.getItem("vt_sidebar_hidden") === "1";
  });
  const [mobileDrawerState, setMobileDrawerState] = useState<MobileDrawerState>("closed");
  const mobileDrawerTimerRef = useRef<number | null>(null);
  const mobileDrawerFrameRef = useRef<number | null>(null);
  const mobileDrawerContainerRef = useRef<HTMLDivElement | null>(null);

  const clearMobileDrawerTimers = () => {
    if (typeof window === "undefined") return;
    if (mobileDrawerTimerRef.current !== null) {
      window.clearTimeout(mobileDrawerTimerRef.current);
      mobileDrawerTimerRef.current = null;
    }
    if (mobileDrawerFrameRef.current !== null) {
      window.cancelAnimationFrame(mobileDrawerFrameRef.current);
      mobileDrawerFrameRef.current = null;
    }
  };

  const openMobileDrawer = () => {
    if (typeof window === "undefined") return;
    if (mobileDrawerState === "open" || mobileDrawerState === "opening") return;
    clearMobileDrawerTimers();
    setSidebarHidden(true);
    setMobileDrawerState("opening");
    mobileDrawerFrameRef.current = window.requestAnimationFrame(() => {
      setMobileDrawerState("open");
      mobileDrawerFrameRef.current = null;
    });
  };

  const closeMobileDrawer = () => {
    if (typeof window === "undefined") return;
    if (mobileDrawerState === "closed" || mobileDrawerState === "closing") return;
    clearMobileDrawerTimers();
    const activeElement = document.activeElement;
    if (
      activeElement instanceof HTMLElement &&
      mobileDrawerContainerRef.current?.contains(activeElement)
    ) {
      activeElement.blur();
    }
    setMobileDrawerState("closing");
    mobileDrawerTimerRef.current = window.setTimeout(() => {
      setMobileDrawerState("closed");
      mobileDrawerTimerRef.current = null;
    }, MOBILE_DRAWER_ANIMATION_MS);
  };

  const toggleMobileDrawer = () => {
    if (mobileDrawerState === "open" || mobileDrawerState === "opening") {
      closeMobileDrawer();
      return;
    }
    openMobileDrawer();
  };

  const isMobileDrawerMounted = mobileDrawerState !== "closed";
  const isMobileDrawerVisible = mobileDrawerState === "open";

  useEffect(() => {
    const sync = () => {
      const next = syncEntitlementIfDrifted();
      setEntitlement((previous) =>
        entitlementStatesEqual(previous, next) ? previous : next,
      );
    };
    const onEntitlementChanged = (event: Event) => {
      const detail = (event as CustomEvent<EntitlementState>).detail;
      if (!detail) {
        sync();
        return;
      }
      setEntitlement((previous) =>
        entitlementStatesEqual(previous, detail) ? previous : detail,
      );
    };
    sync();
    window.addEventListener("storage", sync);
    window.addEventListener(ENTITLEMENT_CHANGED_EVENT, onEntitlementChanged as EventListener);
    return () => {
      window.removeEventListener("storage", sync);
      window.removeEventListener(ENTITLEMENT_CHANGED_EVENT, onEntitlementChanged as EventListener);
    };
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const media = window.matchMedia("(max-width: 767px)");
    const syncMobile = (event?: MediaQueryListEvent) => {
      const nextMobile = event ? event.matches : media.matches;
      setIsMobile(nextMobile);
      setSidebarHidden((current) => {
        if (nextMobile) return true;
        return localStorage.getItem("vt_sidebar_hidden") === "1" ? true : current;
      });
      if (!nextMobile) {
        clearMobileDrawerTimers();
        setMobileDrawerState("closed");
      }
    };

    syncMobile();
    media.addEventListener("change", syncMobile);
    return () => media.removeEventListener("change", syncMobile);
  }, []);

  useEffect(() => {
    if (!isMobile) return;
    closeMobileDrawer();
  }, [location.pathname, isMobile]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (isMobile) return;
    localStorage.setItem("vt_sidebar_hidden", sidebarHidden ? "1" : "0");
  }, [sidebarHidden, isMobile]);

  useEffect(() => {
    if (!isMobile || typeof document === "undefined") return;
    document.body.style.overflow = isMobileDrawerMounted ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isMobile, isMobileDrawerMounted]);

  useEffect(() => {
    if (!isMobile || typeof document === "undefined") return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      closeMobileDrawer();
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [isMobile]);

  useEffect(() => {
    return () => clearMobileDrawerTimers();
  }, []);

  const isLarge = entitlement.tier === "large";
  const isFree = entitlement.tier === "free";
  const isEditorSurface =
    location.pathname === "/editor" || location.pathname === "/editor-v1";
  const tokenText =
    isLarge ? "UNLIMITED" : `${Math.max(0, Math.floor(entitlement.creditBalance)).toLocaleString()} CREDITS`;

  return (
    <DashboardProvider>
      <div className="flex flex-col h-screen w-screen bg-[#f3f4f6] overflow-hidden font-sans">
        <TopBar
          isMobile={isMobile}
          sidebarHidden={sidebarHidden}
          isMobileNavOpen={isMobileDrawerVisible}
          onToggleSidebar={() => (isMobile ? toggleMobileDrawer() : setSidebarHidden((value) => !value))}
        />
        <div className="flex flex-1 h-0 w-full overflow-visible relative">
          {!isMobile && !sidebarHidden ? <Sidebar onHide={() => setSidebarHidden(true)} /> : null}
          {isMobile && isMobileDrawerMounted ? (
            <>
              <button
                type="button"
                aria-label="Close navigation"
                className={`absolute inset-0 z-[170] bg-black/20 backdrop-blur-[2px] transition-opacity duration-300 ${
                  isMobileDrawerVisible ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
                }`}
                onClick={closeMobileDrawer}
              />
              <div
                ref={mobileDrawerContainerRef}
                aria-hidden={!isMobileDrawerVisible}
                className={`absolute left-3 top-3 bottom-3 z-[180] w-[min(24rem,calc(100vw-1.5rem))] transition-transform duration-300 ease-out ${
                  isMobileDrawerVisible ? "translate-x-0 pointer-events-auto" : "-translate-x-[110%] pointer-events-none"
                }`}
              >
                <Sidebar mobile onHide={closeMobileDrawer} onNavigate={closeMobileDrawer} />
              </div>
            </>
          ) : null}
          <main
            className={`flex-1 h-full overflow-y-auto overflow-x-hidden relative ${
              isEditorSurface
                ? isMobile ? "p-1.5 pb-4" : "p-2 pb-2"
                : isMobile ? "p-3 pb-24" : "p-8 pb-96"
            }`}
          >
            <EntitlementContext.Provider value={entitlement}>{children}</EntitlementContext.Provider>
          </main>
          {location.pathname === "/" && sidebarHidden && !isMobile && (
            <div className="absolute bottom-4 left-4 z-50 flex gap-3 text-[10px] text-gray-500 font-semibold bg-white/80 backdrop-blur-sm px-2 py-1 rounded border border-black/10">
              <a href="/privacy.html" className="hover:text-black underline">Privacy Policy</a>
              <span>•</span>
              <a href="/terms.html" className="hover:text-black underline">Terms of Service</a>
            </div>
          )}
        </div>
      </div>
    </DashboardProvider>
  );
};
